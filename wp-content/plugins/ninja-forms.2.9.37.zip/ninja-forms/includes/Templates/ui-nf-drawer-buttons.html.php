<ul class="nf-drawer-buttons">
    <li class="nf-drawer-delete"><span class="dashicons dashicons-dismiss"></span>Delete</li>
    <li class="nf-drawer-duplicate"><span class="dashicons dashicons-admin-page"></span>Duplicate</li>
</ul>
