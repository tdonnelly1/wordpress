<div id="nf-menu-drawer">
    <ul>
        <li class="nf-publish">Publish</li>
    </ul>
    <ul>
        <li><a href="#"><span class="dashicons dashicons-menu"></span>Form Fields</a></li>
        <li><a href="http://three.ninjaforms.com/wp-admin/admin.php?page=edit-action"><span class="dashicons dashicons-external"></span>Emails & Actions</a></li>
        <li><a href="#"><span class="dashicons dashicons-admin-generic"></span>Settings</a></li>
        <li><a href="#"><span class="dashicons dashicons-visibility"></span>Preview</a></li>
    </ul>
</div>
